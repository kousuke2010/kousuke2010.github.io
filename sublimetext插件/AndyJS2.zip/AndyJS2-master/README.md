AndyJS2 (Previously AndyJS)
======

JS and jQuery completions ST2

The jQuery completions require a syntax file - there is one available via PackageControl. 
Once this file is installed you can switch between JS and jQuery using the syntax options 
at the bottom-right of the view.

If you only require one of these completions files then you can still install both and 
just delete the other file. (Be aware, though, that it may be re-installed on a future update.)
However, if you are not using jQuery, then you do not need to delete the completions file, as 
it will just be ignored.
